#ifndef WAIT_H
#define WAIT_H

#include "LPC407x_8x_177x_8x.h"

void wait(uint32_t miliseconds);

void waitMicroseconds(uint32_t microseconds);

#endif
